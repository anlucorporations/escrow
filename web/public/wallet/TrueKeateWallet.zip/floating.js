const n="codecrypto_view_mode",c="codecrypto-floating-host";let r=null;const l=`
  :host { all: initial; }
  #cc-btn {
    position: fixed; right: 18px; bottom: 18px; z-index: 2147483646;
    width: 48px; height: 48px; border-radius: 9999px; border: 0; cursor: pointer;
    background: linear-gradient(135deg, #1a2b4c 0%, #2a9d8f 100%); color: #fff;
    font-size: 22px; box-shadow: 0 8px 24px rgba(0,0,0,.35);
  }
  #cc-btn:hover { filter: brightness(1.1); }
  #cc-panel {
    position: fixed; right: 18px; bottom: 76px; z-index: 2147483647;
    width: 380px; height: 600px; max-height: calc(100vh - 100px); display: none;
    background: #fff; border-radius: 16px; overflow: hidden;
    box-shadow: 0 18px 48px rgba(0,0,0,.4); border: 1px solid rgba(26,43,76,.12);
  }
  #cc-panel.abierto { display: flex; flex-direction: column; }
  #cc-barra {
    display: flex; align-items: center; justify-content: space-between;
    padding: 8px 12px; background: #1a2b4c; color: #fff;
    font-family: Inter, -apple-system, sans-serif; font-size: 12px; font-weight: 600;
  }
  #cc-cerrar { border: 0; background: rgba(255,255,255,.15); color: #fff; border-radius: 8px; cursor: pointer; padding: 2px 8px; }
  #cc-frame { flex: 1; border: 0; width: 100%; background: #f8f9fa; }
`;function p(){if(document.getElementById(c))return;r=document.createElement("div"),r.id=c,document.documentElement.appendChild(r);const t=r.attachShadow({mode:"open"}),a=document.createElement("style");a.textContent=l,t.appendChild(a);const e=document.createElement("button");e.id="cc-btn",e.type="button",e.title="TrueKeate Wallet",e.setAttribute("aria-label","Abrir TrueKeate Wallet"),e.textContent="🔐",t.appendChild(e);const o=document.createElement("div");o.id="cc-panel",o.innerHTML=`
    <div id="cc-barra">
      <span>CodeCrypto Wallet</span>
      <button id="cc-cerrar" type="button" aria-label="Cerrar">✕</button>
    </div>
    <iframe id="cc-frame" title="CodeCrypto Wallet" src="${chrome.runtime.getURL("index.html")}"></iframe>
  `,t.appendChild(o);const d=()=>o.classList.toggle("abierto");e.addEventListener("click",d),o.querySelector("#cc-cerrar")?.addEventListener("click",()=>o.classList.remove("abierto"))}function s(){r?.remove(),r=null}async function i(){try{(await chrome.storage.local.get(n))[n]==="flotante"?p():s()}catch{}}i();chrome.storage.onChanged.addListener((t,a)=>{a==="local"&&t[n]&&i()});
