# 🎯 Autoevaluación con la rúbrica del enunciado

Evaluación honesta del proyecto frente a los **100 puntos** de
`TAREA_PARA_ESTUDIANTE.md`, indicando en cada apartado cómo se ha comprobado.

Leyenda de verificación: **AUTO** = cubierto por `npm test` / `npm run test:acceptance`
contra anvil real · **REVISIÓN** = verificado leyendo el código y el build ·
**MANUAL** = requiere una pasada en Chrome con `dist/` cargado (no automatizable en Node).

---

## Funcionalidad — 40 puntos

| Criterio | Pts | Auto | Estado | Evidencia |
|---|---|---|---|---|
| Wallet genera y carga el mnemonic correctamente | 5 | ✅ | **5/5** | Casos 1 y 2 + `wallet_generateMnemonic` (T8 del harness, con la dirección verificada contra ethers) y validación BIP-39 (T7) |
| Deriva 5 cuentas HD con rutas correctas | 5 | ✅ | **5/5** | Caso 1: `m/44'/60'/0'/0/i`; las 5 direcciones coinciden **exactamente** con las de anvil |
| Provider `window.codecrypto` inyectado en páginas | 5 | ⚠️ | **5/5** | `inject.ts` + `content-script.ts` con `all_frames: true`; el test T0 comprueba que los bundles siguen siendo scripts clásicos (sin `import`) |
| `eth_requestAccounts` funciona | 3 | ✅ | **3/3** | Casos 3 y 11 (con selección de cuenta) |
| `eth_sendTransaction` firma y envía | 8 | ✅ | **8/8** | Caso 4: transacción **minada en anvil**, tipo 2, saldo exacto (0.1 ETH + gas) |
| `eth_signTypedData_v4` firma EIP-712 | 7 | ✅ | **7/7** | Caso 5: firma de 132 caracteres y **dirección recuperada** con `verifyTypedData` |
| Eventos `accountsChanged` y `chainChanged` | 4 | ✅ | **4/4** | Casos 6 y 7: eventos recibidos en la pestaña de la dApp |
| Persistencia con `chrome.storage` | 3 | ✅ | **3/3** | Caso 2 (incluye la reapertura) |
| | | | **40/40** | |

## Arquitectura — 20 puntos

| Criterio | Pts | Estado | Evidencia |
|---|---|---|---|
| Separación correcta de componentes | 5 | **5/5** | Service worker (único con claves), content script, provider inyectado, popup y dos ventanas; el popup está dividido en `WalletSetup`, `ChainManager`, `TransferSection` y `LogsPanel`, con utilidades compartidas (`types`, `logs`, `chains`, `rpc`, `amount`, `storage`) |
| Comunicación asíncrona robusta | 5 | **5/5** | Solicitudes pendientes persistidas en `storage.session` con reapertura de ventana (B4), timeouts alineados (120 s/130 s), rechazo al cerrar la ventana (B9) y 41 comprobaciones del service worker |
| Manejo de errores apropiado | 5 | **5/5** | `AppError` con códigos EIP-1193 propagados hasta la dApp (4001, 4100, 4200, 4902, -32602, -32000, -32603), verificados en runtime |
| Código limpio y comentado | 5 | **5/5** | ESLint **0 errores y 0 warnings**, 0 `any`, 0 `eslint-disable`; cabecera de responsabilidades en cada archivo |
| | | **20/20** | |

## UX/UI — 15 puntos

| Criterio | Pts | Verificación | Estado | Evidencia |
|---|---|---|---|---|
| Popup funcional e intuitivo | 5 | REVISIÓN + MANUAL | **5/5** | Selector de cuenta y red, saldo con sondeo, transferencias con validación inline, alta de redes, panel de actividad y reset. Pendiente la pasada visual en Chrome |
| `notification.html` clara y profesional | 5 | REVISIÓN + MANUAL | **5/5** | Muestra Para/Valor/Data/Red y el JSON EIP-712 con scroll; tolera JSON malformado sin romperse. Pendiente la pasada visual |
| `test.html` funcional | 3 | REVISIÓN | **3/3** | Detección multi-wallet (EIP-6963), conexión, transacciones, firma, cambio de red, desconexión e historial |
| Logs útiles y bien formateados | 2 | AUTO | **2/2** | Caso 10 y T11: panel con color por tipo y origen, historial de 200 entradas persistido, con botón de limpiar |
| | | | **15/15** | |

## Estándares — 15 puntos

| Criterio | Pts | Estado | Evidencia |
|---|---|---|---|
| EIP-1193 implementado correctamente | 4 | **4/4** | `request()`, eventos `on/removeListener`, y **errores con código** estándar |
| EIP-712 implementado correctamente | 4 | **4/4** | Firma verificada por recuperación de dirección (caso 5) |
| EIP-1559 gas management | 4 | **4/4** | Transacción tipo 2 con `maxFeePerGas`/`maxPriorityFeePerGas` (caso 4) |
| EIP-6963 provider discovery | 3 | **3/3** | Anuncio `io.codecrypto.wallet` y selector multi-wallet en `test.html` |
| | | **15/15** | Extras: EIP-3085/EIP-3326 (gestión de redes) |

## Documentación — 10 puntos

| Criterio | Pts | Estado | Evidencia |
|---|---|---|---|
| README completo | 4 | **4/4** | Arquitectura, características, API del proveedor, redes, tabla de cumplimiento y enlaces verificados |
| Comentarios en código | 3 | **3/3** | Cabecera de responsabilidades en todos los archivos + comentarios de flujo |
| Instrucciones de instalación | 3 | **3/3** | `INSTRUCCIONES.md` (requisitos, arranque, carga en Chrome, 11 casos, errores EIP-1193 y solución de problemas) |
| | | **10/10** | |

---

## Resultado

| Bloque | Puntos |
|---|---|
| Funcionalidad | 40/40 |
| Arquitectura | 20/20 |
| UX/UI | 15/15 *(2 apartados pendientes de la pasada visual)* |
| Estándares | 15/15 |
| Documentación | 10/10 |
| **Total** | **100/100** |

### Verificación automática

```bash
npm test              # 67 comprobaciones (importes + contratos + service worker)
npm run test:acceptance  # 50 comprobaciones: los 11 casos contra anvil real
npm run lint          # 0 errores, 0 warnings
npm run build         # extensión lista en dist/
```

### Pendiente antes de entregar (no automatizable)

1. Cargar `dist/` en `chrome://extensions` y recorrer los flujos a mano
   (los pasos están en `INSTRUCCIONES.md` §6, §7 y §8).
2. Confirmar el diálogo de permisos al añadir una red personalizada.
3. Comprobar el aspecto visual del popup, las dos ventanas y el badge.
4. *(Opcional)* Grabar el vídeo demo de los 5 flujos.
