# 🎓 Evidencia de los 11 casos de prueba del enunciado

Ejecutado el 12/9/2026, 2:13:30 con `npm run test:acceptance`.

**Entorno**

- Node v22.23.2
- anvil en http://127.0.0.1:8545 (chainId 0x7a69)
- Service worker real: `dist/background.js` con las APIs de `chrome` simuladas (`scripts/lib/chrome-stub.mjs`)
- Casos ejecutados de extremo a extremo contra la cadena: derivación, conexión,
  transacción y transferencia **minadas de verdad en anvil**, firma EIP-712 verificada,
  eventos difundidos a las pestañas, reset, badge y selección de cuenta.

**Resultado global**

| Comprobaciones | Resultado |
|---|---|
| Total | 50 |
| Correctas | 50 |
| Fallidas | 0 |

**Detalle**

| # | Comprobación | Resultado | Evidencia |
|---|---|---|---|
| 1 | se derivan 5 cuentas HD (BIP-44) | ✅ | ["0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266","0x70997970C51812dc3A010C7d01b50e0d17dc79C8","0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC","0x90F79bf6EB2c4f870365E785982E1f101E93b906","0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65"] |
| 2 | las cuentas coinciden con las de anvil | ✅ | 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266 vs 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266 |
| 3 | la cuenta 0 arranca con 10 000 ETH | ✅ | 10000.0 |
| 4 | chainId por defecto 0x7a69 (31337) | ✅ | 0x7a69 |
| 5 | eth_getBalance devuelve el saldo en hex | ✅ | 0x21e19e0c9bab2400000 |
| 6 | el mnemonic, las cuentas, la cuenta activa y la red quedan guardados | ✅ |  |
| 7 | al reabrir se restauran las mismas cuentas y la cuenta activa | ✅ |  |
| 8 | se abre la ventana connect.html | ✅ | [{"url":"connect.html","type":"popup","width":420,"height":650,"focused":true}] |
| 9 | la solicitud incluye el origen de la dApp | ✅ | http://localhost:5173/test.html |
| 10 | la solicitud lleva las 5 cuentas | ✅ |  |
| 11 | la dApp recibe la cuenta seleccionada | ✅ | {"result":["0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"],"error":null} |
| 12 | el permiso se guarda POR ORIGEN | ✅ | {"http://localhost:5173":"0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"} |
| 13 | eth_accounts devuelve la cuenta autorizada | ✅ | {"result":["0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"],"error":null} |
| 14 | un sitio NO autorizado recibe [] | ✅ | {"result":[],"error":null} |
| 15 | se abre la ventana notification.html | ✅ |  |
| 16 | la solicitud muestra destino, valor y red | ✅ | {"from":"0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266","to":"0x70997970C51812dc3A010C7d01b50e0d17dc79C8","value":"0x16345785d8a0000","data":"0x"} |
| 17 | mientras hay una solicitud pendiente, el badge muestra 1 | ✅ | 1 |
| 18 | la dApp recibe el hash de la transacción | ✅ | {"result":"0x1f4b6e1c13d6374c8fabce903e1b3cc947d75be53a8c49b555a63e21b2388d16","error":null} |
| 19 | el badge se apaga al aprobar | ✅ |  |
| 20 | la transacción está minada en anvil | ✅ | status=1 |
| 21 | se envió como EIP-1559 (tipo 2) | ✅ | type=2 |
| 22 | el saldo baja exactamente 0.1 ETH + gas | ✅ | gastado 0.100042 ETH |
| 23 | se abre la ventana de confirmación para firmar | ✅ | eth_signTypedData_v4 |
| 24 | devuelve una firma de 132 caracteres | ✅ | 0x1ef935d1c674b8d33e… (132 caracteres) |
| 25 | la firma corresponde a la cuenta activa | ✅ | 0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC vs 0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC |
| 26 | la dApp recibe el evento accountsChanged | ✅ | 2 eventos |
| 27 | el evento lleva la nueva cuenta | ✅ | [["0x70997970C51812dc3A010C7d01b50e0d17dc79C8"],["0x70997970C51812dc3A010C7d01b50e0d17dc79C8"]] |
| 28 | la cuenta activa queda guardada en storage | ✅ | 1 |
| 29 | la dApp recibe el evento chainChanged | ✅ | 2 eventos |
| 30 | el evento lleva el nuevo chainId | ✅ | ["0xaa36a7","0xaa36a7"] |
| 31 | cambiar a una red no registrada devuelve 4902 | ✅ | {"code":4902,"message":"Unrecognized chain ID 0x9999. Try adding the chain first with wallet_addEthereumChain."} |
| 32 | hay una solicitud pendiente antes del reset | ✅ | 1 |
| 33 | el reset cancela la solicitud pendiente | ✅ | {"code":4001,"message":"Wallet was reset"} |
| 34 | el badge queda apagado | ✅ |  |
| 35 | no queda ninguna solicitud en storage.session | ✅ |  |
| 36 | el reset borra todas las claves de la wallet | ✅ | ["codecrypto_mnemonic","codecrypto_accounts","codecrypto_connected_sites"] |
| 37 | el reset conserva el historial de logs | ✅ | ["codecrypto_mnemonic","codecrypto_accounts","codecrypto_connected_sites"] |
| 38 | el reset no toca claves ajenas a la wallet | ✅ | ["codecrypto_mnemonic","codecrypto_accounts","codecrypto_connected_sites"] |
| 39 | la transferencia se mina | ✅ | status=1 |
| 40 | la cuenta destino gana exactamente 1 ETH | ✅ | 1.0 ETH |
| 41 | la cuenta origen pierde 1 ETH + gas | ✅ | 1.000039378675 ETH |
| 42 | sin solicitudes pendientes el badge está vacío | ✅ |  |
| 43 | con una solicitud pendiente el badge muestra 1 | ✅ | 1 |
| 44 | se abrió la ventana de confirmación automáticamente | ✅ |  |
| 45 | al resolverse, el badge vuelve a estar vacío | ✅ |  |
| 46 | connect.html muestra el origen de la solicitud | ✅ | http://localhost:5173/otra.html |
| 47 | la ventana de conexión se abre con las 5 cuentas | ✅ |  |
| 48 | la dApp conecta con la Cuenta 3 | ✅ | {"result":["0x90F79bf6EB2c4f870365E785982E1f101E93b906"],"error":null} |
| 49 | la Cuenta 3 queda autorizada para ese origen | ✅ | {"http://localhost:5173":"0x90F79bf6EB2c4f870365E785982E1f101E93b906"} |
| 50 | eth_accounts devuelve la Cuenta 3 | ✅ | {"result":["0x90F79bf6EB2c4f870365E785982E1f101E93b906"],"error":null} |

**Datos de la cadena**

- Cuenta 0: 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266 · saldo 10000.0 ETH
- No hace falta volver a introducir la frase: se relee de chrome.storage.local
- Origen autorizado: http://localhost:5173
- Hash: 0x1f4b6e1c13d6374c8fabce903e1b3cc947d75be53a8c49b555a63e21b2388d16
- Gas usado: 21000 · tipo 2 (EIP-1559) · bloque 1
- Firma: 0x1ef935d1c674b8d33e77c7…
- Dirección recuperada: 0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC
- accountsChanged → 0x70997970C51812dc3A010C7d01b50e0d17dc79C8
- chainChanged → 0xaa36a7 (Sepolia)
- Solicitudes canceladas y badge apagado; el historial de logs se conserva
- Transferencia: 1.0 ETH · hash 0x3829781e6b678cde12ceffd99a779180a0b4db95565d49a1f71960bf6103e85e
- La notificación nativa de Chrome y el popup real se verifican a mano (ver INSTRUCCIONES.md §8)
- Cuenta 3 autorizada para http://localhost:5173: 0x90F79bf6EB2c4f870365E785982E1f101E93b906

**Casos que requieren navegador (MANUAL)**

Estos puntos no se pueden automatizar en Node y se verifican cargando `dist/` en Chrome:
la apertura real de las ventanas `connect.html` / `notification.html`, la notificación
nativa de Chrome, el render del popup (selector de cuentas, panel de actividad, alta de
redes con el diálogo de permisos) y el aspecto visual del badge. Los pasos están en
`INSTRUCCIONES.md` (§6, §7 y §8).
