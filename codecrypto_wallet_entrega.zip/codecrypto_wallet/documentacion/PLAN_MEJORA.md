# 🚀 Plan de Mejora — CodeCrypto Wallet

**Objetivo:** llevar la aplicación al **cumplimiento total** de `TAREA_PARA_ESTUDIANTE.md`
(36 especificaciones funcionales + 11 casos de prueba + rúbrica de 100 puntos), corrigiendo
los defectos detectados y elevando la calidad del código y la documentación.

**Fecha:** 2025-10-13 · **Base analizada:** rama `main`, commit `632d890` · **Autor del plan:** agente DSH

---

## 0. Resumen ejecutivo

| Área | Estado actual | Objetivo del plan |
|---|---|---|
| Requisitos funcionales (36) | 32 cumplen · 2 no cumplen · 2 parciales | 36/36 |
| Casos de prueba (11) | No verificados formalmente | 11/11 verificados con evidencia |
| Build (`npm run build`) | ✅ Pasa | ✅ Sigue pasando, con salida documentada |
| Lint (`npm run lint`) | ❌ 30 errores + 1 warning | 0 errores |
| Bugs conocidos | 6 detectados (1 crítico) | 0 |
| Documentación de entrega | README con 6 enlaces rotos, falta `INSTRUCCIONES.md` | Entrega completa y veraz |

**Esfuerzo estimado:** ~30–35 h (encaja en el cronograma de 40 h del enunciado).

### Decisiones acordadas con el usuario

| Tema | Decisión |
|---|---|
| B1 · alcance del permiso | Por **origen/sitio** (como MetaMask), con migración de las claves antiguas |
| B2 · alcance del reset | Borra **todo salvo el historial de logs** |
| B3 · transferencias | Precisión exacta **+ validación de saldo insuficiente inline** |
| B5 · timeouts | Firmas **120 s** (provider 130 s) · conexión **60 s** |
| B4 · worker dormido | **Persistir en `chrome.storage.session`** y reabrir la ventana |
| B6 · iconos | PNG 16/48/128 generados por el proyecto (`scripts/generate-icons.mjs`) |
| B9 · ventana cerrada a mano | Rechazo inmediato con `chrome.windows.onRemoved` |
| Logs sensibles | Eliminar el mnemonic de todos los `console.log` |

---

## 1. Línea base verificada (evidencia)

Ejecutado sobre el clon actual:

| Comprobación | Comando | Resultado |
|---|---|---|
| Dependencias | `npm install` | ✅ 205 paquetes, sin vulnerabilidades reportadas |
| Compilación | `npm run build` | ✅ 194 módulos, `dist/` generado con `manifest.json` |
| Salida | `dist/` | `dist/background.js` 77.77 kB · `App-*.js` 194 kB · `provider-jsonrpc-*.js` 251 kB · `dist/inject.js` 2 kB · `dist/content-script.js` 1.14 kB |
| Calidad | `npm run lint` | ❌ **30 errores + 1 warning** |
| Reglas incumplidas | — | `no-explicit-any` ×24, `no-unused-vars` ×6 |
| Errores por archivo | — | `Connect.tsx` 10 · `Notification.tsx` 8 · `viewextensiondata/` 11 · `content-script.ts` 2 · `inject.ts` 1 |
| Métodos RPC | grep `case '...'` en `background.ts` | 8 implementados; `test.html` solo usa métodos implementados ✅ |

> Nota: el `dist/background.js` real (77.77 kB) y los chunks `units-*.js`/`maths-*.js` difieren de las
> cifras de la sección "Estadísticas" del enunciado (~11 kB). Es desactualización del documento,
> no un defecto del código.

---

## 2. Matriz de cumplimiento de los 36 requisitos funcionales

Leyenda: ✅ cumple · 🟡 parcial · ❌ no cumple

### Parte 1 — Core Wallet

| # | Requisito | Estado | Evidencia / acción |
|---|---|---|---|
| 1 | Mnemonic BIP-39: **generar**/importar 12 palabras | ❌ | Solo hay importación por textarea (`App.tsx` 537-562). No existe `Wallet.createRandom()` ni `Mnemonic.fromEntropy`. **Acción F2.1** |
| 2 | Carga sin contraseña | ✅ | `handleLoadWallet()` → `wallet_deriveAccounts` |
| 3 | Provider `window.codecrypto` | ✅ | `inject.ts` 146-150 (`Object.defineProperty`) |
| 4 | Solo Ethers.js | ✅ | `package.json`: deps = `ethers`, `react`, `react-dom`; sin axios/fetch/viem |
| 5 | React + TypeScript | ✅ | React 19 + TS 5.9, `tsc -b` limpio |
| 6 | RPC por defecto `localhost:8545` / `0x7a69` | ✅ | `background.ts` 400, 508-510; `App.tsx` 161 |

### Parte 2 — Operaciones Blockchain

| # | Requisito | Estado | Evidencia / acción |
|---|---|---|---|
| 7 | `eth_sendTransaction` | ✅ | `background.ts` 528-588 (aprobación + firma + EIP-1559) |
| 8 | `eth_signTypedData_v4` | ✅ | `background.ts` 590-634 |
| 9 | Inyección global | ✅ | `manifest.ts`: `<all_urls>`, `document_start`, `all_frames: true` |
| 10 | Evento `accountsChanged` | ✅ | `background.ts` 93-114 y 668-709 |

### Parte 3 — UX y Logging

| # | Requisito | Estado | Evidencia / acción |
|---|---|---|---|
| 11 | Polling de saldos cada 5 s | ✅ | `App.tsx` 367-374 (`setInterval(updateBalance, 5000)`) |
| 12 | Chrome y Edge (MV3) | ✅ | `manifest_version: 3`, APIs `chrome.*` |
| 13 | Logs de llamadas al proveedor | 🟡 | Se registran en la **consola del service worker**, no en el panel del popup (el mock del enunciado muestra `> eth_requestAccounts` en el popup). **Acción F2.4** |
| 14 | Logs de eventos | 🟡 | Igual que #13: `accountsChanged`/`chainChanged` no se reflejan en el popup |
| 15 | Logs de errores con color | ✅ | `App.css` 231-270 (`.log-error` rojo, `.log-call`, `.log-event`, `.log-message`) |
| 16 | Logs de transacciones y firmas | 🟡 | Solo las iniciadas desde el popup (transferencias), no las de dApps. **Acción F2.4** |

### Parte 4 — Estándares EIP

| # | Requisito | Estado | Evidencia / acción |
|---|---|---|---|
| 17 | EIP-1559 (`maxFeePerGas`, `maxPriorityFeePerGas`) | ✅ | `background.ts` 558-576 (`type: 2`) |
| 18 | EIP-6963 | ✅ | `inject.ts` 154-173 (`io.codecrypto.wallet`) |
| 19 | Cambio de redes | ✅ | `wallet_switchEthereumChain` (636-659) + botones en popup y `test.html` |
| 20 | **Gestión de redes: añadir nuevas redes** | ❌ | No existe `wallet_addEthereumChain` ni UI de alta de red (solo 2 botones fijos, `App.tsx` 611-624). **Acción F2.2** |

### Parte 5 — UI Avanzada

| # | Requisito | Estado | Evidencia / acción |
|---|---|---|---|
| 20 (dup.) | Modal/página de confirmación independiente | ✅ | `notification.html` + `Notification.tsx` (ventana 400×600) |
| 21 | Reset Wallet | ✅ | `App.tsx` 439-469 |
| 22 | Hint interactivo (mnemonic de prueba) | ✅ | `App.tsx` 549-562 (clickeable, autocompleta) |
| 23 | Historial de logs persistente entre resets | 🟡 | Se conservan en estado React durante el reset, pero se pierden al cerrar el popup; el enunciado sugiere `localStorage`. **Acción F2.5** |
| 24 | Transferencias internas | ✅ | `TransferSection` (`App.tsx` 55-153) + `handleTransfer` |
| 25 | Validación de formularios y feedback | 🟡 | Solo `alert()` y `disabled`; sin validación inline ni estado de error en el campo. **Acción F2.3** |

### Parte 6 — Persistencia

| # | Requisito | Estado | Evidencia / acción |
|---|---|---|---|
| 26 | `chrome.storage.local` con las claves del enunciado | ✅ | `codecrypto_mnemonic`, `_accounts`, `_current_account`, `_chain_id`, `_pending_request`, `_connected_sites` |
| 27 | Auto-carga de la wallet | ✅ | `App.tsx` 247-302 |
| 28 | Restaurar cuenta activa y red | ✅ | `loadWalletFromMnemonic(savedChainId, savedAccountIndex)` |

### Parte 7 — Chrome Extension Avanzado

| # | Requisito | Estado | Evidencia / acción |
|---|---|---|---|
| 29 | `notification.html` independiente | ✅ | `background.ts` 189-195 (ventana 400×600) |
| 30 | `connect.html` independiente | ✅ | `background.ts` 266-271 (ventana 420×650) |
| 31 | Badge contador de pendientes | ✅ | `background.ts` 159-160, 369-370 |
| 32 | Notificaciones de Chrome | ✅ | `background.ts` 164-174 |
| 33 | Inyección robusta (todas las páginas y frames) | ✅ | `manifest.ts` 68-81 |
| 34 | `accountsChanged` a todas las pestañas | ✅ | `background.ts` 98-110, 696-707 |
| 35 | `chainChanged` a todas las pestañas | ✅ | `background.ts` 122-134, 716-727 |
| 36 | Selección de cuenta al conectar | ✅ | `Connect.tsx` (radio, balances, origen, 420×650) |

**Resultado:** 32 ✅ · 2 ❌ (#1, #20-redes) · 4 🟡 (#13, #14, #16, #23, #25 → 5 parciales; #13/#14/#16 se cierran con una sola acción)

> ⚠️ El documento numera **dos veces el 20** (Parte 4 "Gestión de Redes" y Parte 5 "Modal de
> Confirmación"), por lo que en realidad enumera 37 ítems bajo el título "36 especificaciones".
> El plan cubre los 37.

---

## 3. Hallazgos técnicos: bugs y riesgos

### 🔴 B1 — CRÍTICO: los sitios conectados nunca quedan autorizados
- **Dónde:** `background.ts` 337 (`connectedSites[origin] = …`, con `origin = sender.tab?.url` → URL **completa**) vs. `background.ts` 479-488 (en `eth_accounts` normaliza a `url.origin` → **solo origen**).
- **Efecto:** `eth_accounts` devuelve `[]` aunque el usuario haya conectado el sitio; las dApps pierden la sesión al recargar. `documentacion/historial/FIX_DESCONEXION_SITIOS.md` documenta "URL completa", contradiciendo el código.
- **Fix:** normalizar a `url.origin` **al guardar** (en `handleConnectResponse`) y migrar claves antiguas al vuelo.

### 🔴 B2 — ALTO: el reset deja datos huérfanos y direcciones obsoletas
- **Dónde:** `App.tsx` 446 (`chrome.storage.local.remove([...4 claves])`).
- **Efecto:** `codecrypto_connected_sites` y `codecrypto_pending_request` sobreviven. Tras resetear e importar **otro** mnemonic, los sitios "conectados" seguirían recibiendo la **dirección antigua**, que ya no pertenece a ninguna cuenta de la wallet.
- **Fix:** limpiar todas las claves `codecrypto_*` (incluidas `_connected_sites` y `_pending_request`), cerrar ventanas de aprobación abiertas y resetear badge.

### 🟠 B3 — Precisión monetaria con punto flotante
- **Dónde:** `App.tsx` 486 (`BigInt(parseFloat(amount) * 1e18)`).
- **Efecto:** errores de redondeo en montos como `0.1 ETH`.
- **Fix:** `ethers.parseEther(amount)` (ya se usa `formatEther` en los componentes de solo lectura).

### 🟠 B4 — Estado de aprobaciones volátil (MV3)
- **Dónde:** `background.ts` 142-147 (`Map` en memoria del service worker).
- **Efecto:** Chrome duerme el worker a los ~30 s; si el usuario tarda en aprobar, los `resolve/reject` se pierden, la ventana queda huérfana y la dApp recibe timeout.
- **Fix:** persistir el pendiente en `chrome.storage.session`, reconstruir el estado al reactivar y cerrar limpiamente (rechazo con código `4001`) cuando no haya ventana viva.

### 🟠 B5 — Timeouts desalineados
- **Dónde:** `inject.ts` 91-95 (30 s) vs. `background.ts` 239 (120 s de aprobación) y 308 (60 s de conexión).
- **Efecto:** la dApp aborta antes de que el usuario pueda aprobar; el mensaje de error es engañoso.
- **Fix:** alinear el timeout del provider con el del background (p. ej. 130 s para firmas) y devolver error EIP-1193 claro (`4001` usuario rechazó, `4902` red no añadida).

### 🟡 B6 — Iconos SVG en el manifest
- **Dónde:** `manifest.ts` 53-67 (`vite.svg`).
- **Efecto:** Chrome no admite SVG como icono de extensión; el icono no se carga correctamente.
- **Fix:** generar PNG 16/48/128 con la identidad CodeCrypto y referenciarlos en `manifest.ts` + `action.default_icon`.

### 🟡 B7 — Versionado incoherente
- `manifest.ts` → `1.0.0`, `package.json` → `0.0.0` y nombre `71_wallet_chrome_extension`, `CHANGELOG.md` → `1.2.0`.
- **Fix:** unificar en `1.3.0` (o la versión que decida el docente) y mantener el CHANGELOG.

### 🟡 B8 — Deuda de lint y de tipos
- 30 errores (24 `no-explicit-any`, 6 `no-unused-vars`), concentrados en `Connect.tsx`, `Notification.tsx` y `viewextensiondata/`.
- **Fix:** extraer los tipos compartidos a `src/types.ts` (hecho en la Fase 3), con uniones discriminadas para los mensajes y una única referencia a `@types/chrome` en lugar de la redeclaración manual de `chrome` que había en `App.tsx`.

### 🟡 B9 — Ventana de aprobación cerrada a mano
- Si el usuario cierra `notification.html`/`connect.html` con la X, el pendiente sobrevive hasta el timeout y el badge queda encendido.
- **Fix:** escuchar `chrome.windows.onRemoved` y resolver como rechazo inmediato.

### 🟡 B10 — Documentación desalineada ✅ RESUELTO en la Fase 0
- `README.md` enlazaba 6 archivos inexistentes: `PASOS_AHORA.md`, `SOLUCION_ERRORES.md`, `START_HERE.md`, `SISTEMA_APROBACION_MEJORADO.md`, `MODAL_APROBACION.md`, `INSTRUCCIONES.md`.
- El README afirmaba "Background.js NO usa ethers.js" y "el popup firma", contradiciendo la arquitectura actual (el background firma).
- **Fix aplicado:** README reescrito y verificado, `INSTRUCCIONES.md` creado y documentación histórica archivada en `documentacion/historial/`.

---

## 4. Plan de ejecución por fases

### Fase 0 — Saneamiento y entrega verificable ✅ COMPLETADA

| # | Tarea | Estado | Resultado |
|---|---|---|---|
| 0.1 | Unificar versiones | ✅ | **1.0.0** en `package.json` y `src/manifest.ts` (decisión del usuario); changelog colapsado a una única entrada 1.0.0 |
| 0.2 | Iconos PNG 16/48/128 | ✅ | `public/icon-*.png` + `scripts/generate-icons.mjs`; el manifest y las notificaciones los usan |
| 0.3 | README veraz + `INSTRUCCIONES.md` | ✅ | README reescrito (arquitectura real, sin enlaces rotos, tabla de cumplimiento del enunciado); `INSTRUCCIONES.md` con instalación, uso, 11 casos de prueba y solución de problemas |
| 0.4 | Archivar documentación | ✅ | `documentacion/historial/` (9 archivos, incluido el volcado de chat de 8,2 MB) + índice en su `README.md`. En la raíz quedan 4 documentos vigentes |
| 0.5 | Script de salud del proyecto | ✅ | `npm run verify` (build + todas las pruebas). `npm run lint` sigue informando de los errores de estilo pendientes de la Fase 3 |

**Decisiones acordadas:** archivar en `documentacion/historial/` (no en `docs/`, que el
`.gitignore` ignora), excluir el volcado de chat del ZIP de entrega, versión de
entrega **1.0.0** con el histórico de versiones aparte, e `INSTRUCCIONES.md` con
instalación + uso + pruebas.

### Fase 1 — Corrección de bugs ✅ COMPLETADA (≈6 h)

| # | Tarea | Estado | Evidencia |
|---|---|---|---|
| 1.1 | **B1** permisos por origen + migración de claves antiguas | ✅ | `background.ts`: `normalizeOrigin()`, `loadConnectedSites()`, `saveConnectedSites()`. Verificado en T1-T3 del harness (4 comprobaciones) |
| 1.2 | **B2** reset completo + aviso al background | ✅ | `App.tsx` borra todas las claves `codecrypto_*` menos los logs; `WALLET_RESET` cierra ventanas, cancela pendientes y limpia badge (T6) |
| 1.3 | **B3** conversión exacta + validación de saldo | ✅ | `src/utils/amount.ts` (sin ethers en el popup, como marca la arquitectura) + validación inline en `TransferSection`. 20 comprobaciones |
| 1.4 | **B4** pendientes en `chrome.storage.session` + reapertura | ✅ | `persistPendingRequests()` / `restorePendingRequests()` en `background.ts`. Verificado en T4 |
| 1.5 | **B5** timeouts alineados | ✅ | `inject.ts` espera 130 s (antes 30 s) y cancela el temporizador al responder. Además: los timeouts ya rechazan con `Error` (antes la dApp recibía `null`) |
| 1.6 | **B9** cierre manual de ventanas | ✅ | `chrome.windows.onRemoved` con 1,5 s de gracia. Verificado en T5 |
| + | **B6** iconos PNG 16/48/128 | ✅ | `scripts/generate-icons.mjs` + `manifest.ts` + notificaciones |
| + | Logs sensibles | ✅ | El mnemonic ya no se imprime en el popup ni en el service worker |

**Verificación:** `npm test` → 20 (importes) + 6 (Foundry) + 19 (service worker) = **45 comprobaciones en verde**; `npm run build` ✅; `npm run lint` sin errores nuevos (los 30 preexistentes se abordan en la Fase 3).

> Desviación respecto al plan: la Fase 1 proponía `ethers.parseEther`, pero el popup
> **no debe importar ethers** (arquitectura del enunciado), así que la conversión se
> implementó con aritmética de cadenas en `src/utils/amount.ts`.

### Fase 2 — Cierre de los requisitos pendientes ✅ COMPLETADA

| # | Tarea | Estado | Evidencia |
|---|---|---|---|
| 2.1 | **Generar wallet** con copia de seguridad guiada | ✅ | `wallet_generateMnemonic` en el background; `src/components/WalletSetup.tsx` muestra las 12 palabras, permite copiarlas y pide confirmar 3 al azar. Verificado en T8 |
| 2.2 | **Gestión de redes** (EIP-3085 / EIP-3326) | ✅ | `wallet_addEthereumChain` + `wallet_switchEthereumChain`, `src/components/ChainManager.tsx`, persistencia en `codecrypto_chains` y selector dinámico. Verificado en T9 y T10 |
| 2.3 | **Validación de formularios** inline | ✅ | `wallet_validateMnemonic` (BIP-39 completo) en el importador, validación de importes/saldo en transferencias y del formulario de red. Verificado en T7 |
| 2.4 | **Bus de logs** hacia el popup | ✅ | `src/utils/logs.ts` publica llamadas, eventos, aprobaciones, hashes y errores; `src/components/LogsPanel.tsx` los pinta con color y origen. Verificado en T11 |
| 2.5 | **Historial persistente** en `chrome.storage.local` | ✅ | 200 entradas, botón de limpiar, conservado por el Reset. Verificado en T11 |

**Decisiones acordadas:** generación en el background (el popup sigue sin ethers) con
confirmación de respaldo; redes desde el popup **y** desde dApps con persistencia;
logs de todo menos el sondeo interno; historial en `chrome.storage.local` (200 entradas);
validación BIP-39 en vivo; y **permisos de host opcionales** (`optional_host_permissions`)
solicitados al añadir cada red, en lugar de pedir acceso a todo internet.

**Resultado:** los 37 requisitos del enunciado quedan cubiertos. El popup se dividió en
componentes (`WalletSetup`, `ChainManager`, `TransferSection`, `LogsPanel`) y las
utilidades compartidas (`logs`, `chains`, `rpc`) se usan desde el background y las interfaces.

### Fase 3 — Calidad de código y tipos ✅ COMPLETADA

| # | Tarea | Estado | Evidencia |
|---|---|---|---|
| 3.1 | `src/types.ts` con mensajes, modelo de datos y `AppError` | ✅ | Unión discriminada `BackgroundMessage`, `Approval`, `ConnectionRequest`, `ChainConfig`, `LogEntry`, códigos de EIP-1193 |
| 3.2 | Tipado de `chrome` unificado | ✅ | Referencia única a `@types/chrome`; `Connect` y `Notification` ya no usan `(window as any)` |
| 3.3 | Errores EIP-1193 de extremo a extremo | ✅ | `AppError` + serialización por los mensajes: la dApp recibe `error.code`. Verificado en las nuevas comprobaciones de T10 |
| 3.4 | `npm run lint` sin errores ni warnings | ✅ | **0 errores, 0 warnings** (antes 30 + 1), incluido `viewextensiondata/` |
| 3.5 | Comentarios de cabecera por archivo | ✅ | Todos los archivos de `src/` documentan su responsabilidad y su flujo |

**Decisiones acordadas:** arreglar el lint en **todo** el repositorio sin exclusiones;
implementar los **códigos EIP-1193 completos** propagados hasta la dApp; y centralizar
**todo** lo compartido en `src/types.ts`.

**Efectos secundarios positivos:** `Notification` ya no se rompe si el JSON del mensaje
EIP-712 llega malformado, `Connect` usa el RPC de la red activa (funciona con redes
personalizadas) y las tablas de errores quedaron documentadas en `INSTRUCCIONES.md`.

### Fase 4 — Pruebas, aceptación y entrega ✅ COMPLETADA

| # | Tarea | Estado | Evidencia |
|---|---|---|---|
| 4.1 | Ejecutar los **11 casos de prueba** del enunciado con anvil | ✅ | `npm run test:acceptance`: **50 comprobaciones** contra anvil real (transacciones minadas de verdad, firma EIP-712 verificada por recuperación de dirección, eventos difundidos, reset, badge y selección de cuenta) |
| 4.2 | Autoevaluación con la rúbrica de 100 puntos | ✅ | `documentacion/AUTOEVALUACION.md` (100/100, marcando lo que queda por verificar a mano) |
| 4.3 | Build final + `dist/` operativo | ✅ | `npm run build` se ejecuta dentro del empaquetado; el ZIP incluye `dist/` ya compilado |
| 4.4 | Empaquetado de entrega | ✅ | `scripts/package-delivery.sh` → `codecrypto_wallet_entrega.zip` (388 KB, 78 archivos; sin `node_modules` ni historial) |
| 4.5 | Vídeo demo | ⏳ | Opcional en el enunciado: exige grabar la pantalla, no automatizable |

**Decisiones acordadas:** nombre genérico del ZIP (`codecrypto_wallet_entrega.zip`)
hasta que el alumno lo renombre con su apellido y nombre, y la evidencia de las
pruebas queda versionada en el repositorio.

**Total de comprobaciones automáticas: 117** (67 con `npm test` + 50 con
`npm run test:acceptance`).

### Fase 5 — Desafíos opcionales del enunciado (≈6 h, solo si se pide)
Dark mode · Export/Import de wallet · Historial on-chain (JSON-RPC, sin APIs externas) · QR para recibir · Multi-idioma.

---

## 5. Protocolo de verificación

```bash
# 1. Blockchain local (terminal 1)
npm run chain                         # anvil → http://127.0.0.1:8545 · chainId 31337

# 2. Extensión (terminal 2)
npm install
npm run build                         # tsc -b && vite build → dist/
# chrome://extensions → Modo desarrollador → Cargar descomprimida → dist/

# 3. dApp de prueba
npx vite preview --port 5174          # sirve test.html en http://localhost:5174/test.html

# 4. Salud del proyecto
npm run lint && npm run build
```

**Checklist de los 11 tests del enunciado:**

| Test | Qué se valida | Evidencia a registrar |
|---|---|---|
| 1 | Inicialización: 5 cuentas, 10 000 ETH, chain 0x7a69 | Captura del popup + consola |
| 2 | Persistencia tras reiniciar Chrome | Captura sin pedir mnemonic |
| 3 | Conexión desde dApp con `connect.html` | Captura de la ventana + `Conectado a: 0x…` |
| 4 | Transacción desde dApp (Para/Valor/Red) | Hash en `test.html` + TX en anvil |
| 5 | Firma EIP-712 (JSON con scroll, firma de 132 chars) | Firma + longitud |
| 6 | Cambio de cuenta → `accountsChanged` | Log del evento en `test.html` |
| 7 | Cambio de red → `chainChanged` | UI "Red: Sepolia" |
| 8 | Reset → storage vacío y logs conservados | Consola de storage |
| 9 | Transferencia interna 1 ETH + gas | Balances antes/después |
| 10 | Badge + notificación de Chrome | Captura del badge "1" |
| 11 | Selección de cuenta al conectar (Cuenta 3) | Captura + cuenta activa en popup |

---

## 6. Rúbrica objetivo

| Bloque | Puntos | Cómo se asegura |
|---|---|---|
| Funcionalidad | 40 | Fases 1-2 (todos los métodos y eventos verificados en Fase 4) |
| Arquitectura | 20 | Fase 3 (tipos, errores centralizados, comunicación robusta con pendientes persistidos) |
| UX/UI | 15 | Fase 2 (validación inline, log bus en popup, gestión de redes, generar wallet) |
| Estándares | 15 | Ya cubierto (1193/712/1559/6963) + códigos de error `4001`/`4902` |
| Documentación | 10 | Fase 0 (README veraz, `INSTRUCCIONES.md`, comentarios) |
| **Total** | **100** | — |

---

## 7. Riesgos y decisiones abiertas

| Tema | Riesgo | Recomendación |
|---|---|---|
| Cifrado del mnemonic | El enunciado asume texto plano ("solo desarrollo") | **No cifrar** (fuera de alcance y rompería la carga sin contraseña); documentarlo como limitación |
| Cierre de las ventanas | Cambiar a `storage.session` altera la reconexión tras dormir el worker | Implementar con prueba manual de 40 s |
| Redes personalizadas | Persistir chains nuevas cambia el esquema de storage | Añadir `codecrypto_chains` con migración tolerante (si no existe, usar las 2 por defecto) |
| `test.html` requiere servidor HTTP | Abrir con `file://` rompería EIP-6963 y los content scripts | Documentar en `INSTRUCCIONES.md` el uso de `vite preview`/`http-server` |
| Nodo local (Foundry) | `anvil`/`forge`/`cast` son dependencias externas al proyecto | ✅ Resuelto: `foundry.toml` + scripts npm (`chain`, `contracts:build`, `contracts:test`, `contracts:deploy`) y requisitos en el README |

---

## 8. Orden recomendado de ejecución

```
Fase 0 (saneamiento)  →  Fase 1 (bugs)  →  Fase 2 (requisitos)  →  Fase 3 (calidad)  →  Fase 4 (pruebas/entrega)
     3 h                    6 h                  8 h                   6 h                  7 h
                                                        ↘ Fase 5 (opcional, 6 h)
```

Cada fase termina con `npm run lint` + `npm run build` en verde y un commit descriptivo
(`fix:`, `feat:`, `docs:`, `chore:`), de modo que la entrega sea auditable.
