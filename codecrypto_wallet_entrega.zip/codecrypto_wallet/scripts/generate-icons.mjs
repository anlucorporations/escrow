#!/usr/bin/env node
/**
 * scripts/generate-icons.mjs — Genera los iconos PNG de la extensión.
 *
 * Chrome no admite SVG como icono de extensión (manifest `icons` y
 * `action.default_icon` requieren PNG), así que este script dibuja el símbolo
 * de CodeCrypto Wallet y lo exporta en 16, 48 y 128 px.
 *
 * Diseño: cuadrado redondeado con degradado verde y una "C" (anillo con
 * abertura) en blanco, que se lee bien incluso a 16 px.
 *
 * Uso:
 *   node scripts/generate-icons.mjs
 *
 * No usa dependencias externas: codifica el PNG con zlib (built-in).
 */
import { deflateSync } from 'node:zlib'
import { writeFileSync, mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const SIZES = [16, 48, 128]
const SS = 4 // supersampling para bordes suaves (anti-aliasing)

// ── Paleta (coherente con el proveedor EIP-6963: #4CAF50) ───────────
const GREEN_TOP = [76, 175, 80]   // #4CAF50
const GREEN_BOTTOM = [27, 94, 32] // #1B5E20
const WHITE = [255, 255, 255, 255]

// ── Codificación PNG (RGBA, 8 bits) ────────────────────────────────
const CRC_TABLE = (() => {
  const table = new Int32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    table[n] = c
  }
  return table
})()

function crc32(buf) {
  let c = 0xffffffff
  for (const byte of buf) c = CRC_TABLE[(c ^ byte) & 0xff] ^ (c >>> 8)
  return (c ^ 0xffffffff) >>> 0
}

function chunk(type, data) {
  const length = Buffer.alloc(4)
  length.writeUInt32BE(data.length, 0)
  const typeAndData = Buffer.concat([Buffer.from(type, 'ascii'), data])
  const crc = Buffer.alloc(4)
  crc.writeUInt32BE(crc32(typeAndData), 0)
  return Buffer.concat([length, typeAndData, crc])
}

function encodePNG(width, height, rgba) {
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(width, 0)
  ihdr.writeUInt32BE(height, 4)
  ihdr[8] = 8 // bit depth
  ihdr[9] = 6 // color type: RGBA
  // 10..12 = compression, filter, interlace = 0

  // Cada scanline lleva su byte de filtro (0 = None)
  const raw = Buffer.alloc((width * 4 + 1) * height)
  for (let y = 0; y < height; y++) {
    const rowStart = y * (width * 4 + 1)
    raw[rowStart] = 0
    rgba.copy(raw, rowStart + 1, y * width * 4, (y + 1) * width * 4)
  }

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ])
}

// ── Dibujo ─────────────────────────────────────────────────────────
/** @returns {{r:number,g:number,b:number,a:number}} color del píxel (0..1) */
function sample(u, v) {
  // u, v ∈ [0,1) dentro del icono
  const size = 1
  const radius = size * 0.22 // esquinas redondeadas
  const x = u - 0.5
  const y = v - 0.5
  const r = radius

  // Distancia al cuadrado redondeado (signed distance field simplificado)
  const qx = Math.abs(x) - (0.5 - r)
  const qy = Math.abs(y) - (0.5 - r)
  const dist =
    Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r
  if (dist > 0) return { r: 0, g: 0, b: 0, a: 0 } // fuera de la forma

  // Degradado vertical
  const t = v
  const bg = {
    r: (GREEN_TOP[0] + (GREEN_BOTTOM[0] - GREEN_TOP[0]) * t) / 255,
    g: (GREEN_TOP[1] + (GREEN_BOTTOM[1] - GREEN_TOP[1]) * t) / 255,
    b: (GREEN_TOP[2] + (GREEN_BOTTOM[2] - GREEN_TOP[2]) * t) / 255,
  }

  // Anillo blanco con abertura a la derecha → forma de "C"
  const cx = x
  const cy = y
  const ringR = 0.27
  const ringW = 0.095
  const d = Math.hypot(cx, cy)
  const inRing = d <= ringR && d >= ringR - ringW
  if (inRing) {
    const angle = Math.atan2(cy, cx) // -π..π, 0 = derecha
    const gap = 0.42 // ~24° de abertura a cada lado
    if (Math.abs(angle) > gap) return { ...bg, ...{ r: WHITE[0] / 255, g: WHITE[1] / 255, b: WHITE[2] / 255 } }
  }

  return { ...bg, a: 1 }
}

function renderIcon(size) {
  const big = size * SS
  const rgba = Buffer.alloc(size * size * 4)

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let r = 0
      let g = 0
      let b = 0
      let a = 0
      // Promedio de los SS×SS subpíxeles (anti-aliasing)
      for (let sy = 0; sy < SS; sy++) {
        for (let sx = 0; sx < SS; sx++) {
          const u = (x * SS + sx + 0.5) / big
          const v = (y * SS + sy + 0.5) / big
          const c = sample(u, v)
          r += c.r * (c.a ?? 1)
          g += c.g * (c.a ?? 1)
          b += c.b * (c.a ?? 1)
          a += c.a ?? 1
        }
      }
      const n = SS * SS
      const alpha = a / n
      const idx = (y * size + x) * 4
      if (alpha > 0) {
        rgba[idx] = Math.round((r / n / alpha) * 255)
        rgba[idx + 1] = Math.round((g / n / alpha) * 255)
        rgba[idx + 2] = Math.round((b / n / alpha) * 255)
        rgba[idx + 3] = Math.round(alpha * 255)
      }
    }
  }

  return encodePNG(size, size, rgba)
}

mkdirSync(resolve(ROOT, 'public'), { recursive: true })
for (const size of SIZES) {
  const file = resolve(ROOT, 'public', `icon-${size}.png`)
  writeFileSync(file, renderIcon(size))
  console.log(`✅ ${file}`)
}
