/// <reference types="chrome"/>
import { useCallback, useEffect, useRef, useState } from 'react'
import './App.css'
import ChainManager from './components/ChainManager'
import LogsPanel from './components/LogsPanel'
import TransferSection from './components/TransferSection'
import WalletSetup from './components/WalletSetup'
import { formatWeiToEth, parseEthToWei } from './utils/amount'
import { LOCAL_CHAIN_ID, mergeChains } from './utils/chains'
import {
  MAX_LOG_ENTRIES,
  appendLog,
  clearLogs,
  createLogEntry,
  isSameEntry,
  loadLogs
} from './utils/logs'
import { notifyWalletReset, sendRPCToBackground } from './utils/rpc'
import { walletKeysToReset } from './utils/storage'
import type { ChainConfig, LogEntry, LogMessage, LogType } from './types'

/**
 * Popup principal de la wallet.
 *
 * Es solo interfaz: no importa ethers ni maneja claves. Toda la criptografía
 * (derivación de cuentas, firmas y envío de transacciones) ocurre en el service
 * worker, al que se piden las operaciones por RPC.
 */
function App() {
  const [isWalletLoaded, setIsWalletLoaded] = useState(false)
  const [accounts, setAccounts] = useState<string[]>([])
  const [currentAccountIndex, setCurrentAccountIndex] = useState(0)
  const [balance, setBalance] = useState('0')
  const [balanceWei, setBalanceWei] = useState<bigint>(0n)
  const [chainId, setChainId] = useState(LOCAL_CHAIN_ID)
  const [chains, setChains] = useState<ChainConfig[]>(() => mergeChains([]))
  const [logs, setLogs] = useState<LogEntry[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const bootstrapped = useRef(false)

  // ── Bus de logs ─────────────────────────────────────────────────────
  const addLog = useCallback((type: LogType, content: string, source = 'wallet') => {
    const entry = createLogEntry(type, content, source)
    setLogs((prev) => [...prev, entry].slice(-MAX_LOG_ENTRIES))
    void appendLog(entry)
  }, [])

  // Historial guardado + entradas que publica el service worker (actividad de dApps)
  useEffect(() => {
    void loadLogs().then((stored) => setLogs(stored.slice(-MAX_LOG_ENTRIES)))

    const listener = (message: unknown) => {
      const msg = message as LogMessage
      if (msg?.type !== 'CODECRYPTO_LOG' || !msg.entry) return
      setLogs((prev) => {
        if (isSameEntry(prev[prev.length - 1], msg.entry)) return prev
        return [...prev, msg.entry].slice(-MAX_LOG_ENTRIES)
      })
    }

    chrome.runtime.onMessage.addListener(listener)
    return () => chrome.runtime.onMessage.removeListener(listener)
  }, [])

  const handleClearLogs = useCallback(async () => {
    await clearLogs()
    setLogs([])
  }, [])

  // ── Redes ───────────────────────────────────────────────────────────
  const refreshChains = useCallback(async () => {
    try {
      const list = await sendRPCToBackground<ChainConfig[]>('wallet_getChains')
      if (Array.isArray(list) && list.length > 0) setChains(list)
    } catch (error) {
      console.error('No se pudieron cargar las redes:', error)
    }
  }, [])

  // ── Carga de la wallet ──────────────────────────────────────────────
  const applyWallet = useCallback(async (
    phrase: string,
    options?: { accountIndex?: number; chainId?: string; persist?: boolean }
  ) => {
    const normalized = phrase.trim().replace(/\s+/g, ' ').toLowerCase()
    if (normalized.split(' ').length !== 12) {
      throw new Error('La frase debe tener exactamente 12 palabras')
    }

    const derived = await sendRPCToBackground<string[]>('wallet_deriveAccounts', [normalized, 5])
    const index = options?.accountIndex ?? 0
    const activeChain = options?.chainId || chainId

    setAccounts(derived)
    setCurrentAccountIndex(index)
    setChainId(activeChain)
    setIsWalletLoaded(true)
    setIsLoading(false)

    if (options?.persist !== false) {
      await new Promise<void>((resolve) => {
        chrome.storage.local.set({
          codecrypto_mnemonic: normalized,
          codecrypto_accounts: derived,
          codecrypto_current_account: index.toString(),
          codecrypto_chain_id: activeChain
        }, () => resolve())
      })
      addLog('event', `Wallet guardada · ${derived.length} cuentas derivadas`, 'wallet')
    }
  }, [chainId, addLog])

  const handleLoadWallet = useCallback(async (phrase: string) => {
    await applyWallet(phrase, { persist: true })
  }, [applyWallet])

  // Arranque: redes + wallet guardada (solo la primera vez)
  useEffect(() => {
    if (bootstrapped.current) return
    bootstrapped.current = true

    const bootstrap = async () => {
      await refreshChains()
      try {
        const stored = await new Promise<Record<string, unknown>>((resolve) => {
          chrome.storage.local.get([
            'codecrypto_mnemonic',
            'codecrypto_current_account',
            'codecrypto_chain_id'
          ], (result) => resolve(result))
        })

        const savedMnemonic = stored.codecrypto_mnemonic as string | undefined
        if (!savedMnemonic) {
          setIsLoading(false)
          return
        }

        await applyWallet(savedMnemonic, {
          accountIndex: parseInt((stored.codecrypto_current_account as string) || '0'),
          chainId: (stored.codecrypto_chain_id as string) || LOCAL_CHAIN_ID,
          persist: false
        })
      } catch (error) {
        addLog('error', `No se pudo cargar la wallet: ${(error as Error).message}`)
        setIsLoading(false)
      }
    }

    void bootstrap()
    // El guardia `bootstrapped` garantiza que el arranque ocurra una sola vez,
    // aunque las dependencias cambien (p. ej. al cambiar de red)
  }, [addLog, applyWallet, refreshChains])

  // ── Balance (sondeo cada 5 s) ───────────────────────────────────────
  const updateBalance = useCallback(async () => {
    if (!isWalletLoaded || !accounts.length) return

    try {
      const balanceHex = await sendRPCToBackground<string>('eth_getBalance', [accounts[currentAccountIndex], 'latest'])
      // Se guarda el wei exacto (bigint) para validar el saldo y el formato
      // legible para mostrarlo; nada de Number() que perdería precisión.
      const wei = BigInt(balanceHex)
      setBalanceWei(wei)
      setBalance(formatWeiToEth(wei))
    } catch (error) {
      // Silenciar errores de sondeo (el nodo puede estar apagado)
      console.error('Error actualizando balance:', error)
    }
  }, [isWalletLoaded, accounts, currentAccountIndex])

  useEffect(() => {
    if (!isWalletLoaded || !accounts.length) return

    void updateBalance()
    const interval = setInterval(() => void updateBalance(), 5000)

    return () => clearInterval(interval)
  }, [isWalletLoaded, accounts, currentAccountIndex, chainId, updateBalance])

  // ── Cambios de cuenta y de red ──────────────────────────────────────
  const changeAccount = (index: number) => {
    if (index >= accounts.length || index < 0) {
      addLog('error', 'Índice de cuenta inválido')
      return
    }

    setCurrentAccountIndex(index)
    addLog('event', `Cuenta cambiada a ${accounts[index].slice(0, 10)}…`)

    chrome.storage.local.set({ codecrypto_current_account: index.toString() }, () => {
      chrome.runtime.sendMessage({
        type: 'ACCOUNT_CHANGED',
        accountIndex: index,
        account: accounts[index]
      }, () => { void chrome.runtime.lastError })
    })
  }

  const changeChain = (newChainId: string) => {
    setChainId(newChainId)
    const chain = chains.find((item) => item.chainId === newChainId)
    addLog('event', `Red cambiada a ${chain?.name || newChainId}`)

    chrome.storage.local.set({ codecrypto_chain_id: newChainId }, () => {
      chrome.runtime.sendMessage({ type: 'CHAIN_CHANGED', chainId: newChainId }, () => {
        void chrome.runtime.lastError
      })
    })
  }

  // ── Reset ───────────────────────────────────────────────────────────
  const resetWallet = () => {
    addLog('event', 'Reseteando wallet…')

    // Se borran TODAS las claves de la wallet (mnemonic, cuentas, cuenta activa,
    // red, sitios conectados, redes personalizadas y solicitudes pendientes),
    // pero se conserva el historial de logs (requisito 23 y Test 8).
    chrome.storage.local.get(null, (all) => {
      const keys = walletKeysToReset(Object.keys(all))
      chrome.storage.local.remove(keys, () => {
        addLog('event', `Datos de extensión limpiados (${keys.length} claves)`)
      })
    })

    // El background cierra las ventanas abiertas y cancela sus solicitudes
    notifyWalletReset()

    setIsWalletLoaded(false)
    setAccounts([])
    setCurrentAccountIndex(0)
    setBalance('0')
    setBalanceWei(0n)
    setChainId(LOCAL_CHAIN_ID)
    void refreshChains()

    addLog('event', '✅ Wallet reseteada · ingresa o crea una nueva frase')
  }

  // ── Transferencias ──────────────────────────────────────────────────
  const handleTransfer = async (toAccountIndex: number, amount: string) => {
    if (!isWalletLoaded) return

    try {
      addLog('message', `Transferencia de ${amount} ETH a la cuenta ${toAccountIndex}`)

      // Conversión EXACTA ETH → wei (antes: BigInt(parseFloat(amount) * 1e18),
      // que desviaba importes reales: 1.1 ETH → 1100000000000000128 wei)
      const valueWei = parseEthToWei(amount)
      if (valueWei > balanceWei) {
        throw new Error(`Saldo insuficiente: disponible ${formatWeiToEth(balanceWei)} ETH`)
      }

      const tx = {
        to: accounts[toAccountIndex],
        value: '0x' + valueWei.toString(16),
        from: accounts[currentAccountIndex]
      }

      const txHash = await sendRPCToBackground<string>('eth_sendTransaction', [tx])
      addLog('event', `Transacción enviada: ${txHash.slice(0, 18)}…`)

      await new Promise((resolve) => setTimeout(resolve, 2000))
      await updateBalance()
      addLog('event', '✅ Transacción confirmada')

      return txHash
    } catch (error) {
      const err = error as Error
      addLog('error', `Error en transferencia: ${err.message}`)
      throw err
    }
  }

  // ── Render ──────────────────────────────────────────────────────────
  return (
    <div className="app">
      <h1>CodeCrypto Wallet</h1>

      {isLoading ? (
        <div className="wallet-setup-container">
          <div className="wallet-setup">
            <h2>⏳ Cargando wallet...</h2>
            <p className="setup-note">Verificando si hay una wallet guardada</p>
          </div>
        </div>
      ) : !isWalletLoaded ? (
        <>
          <WalletSetup onLoadWallet={handleLoadWallet} />
          <LogsPanel logs={logs} onClear={handleClearLogs} />
        </>
      ) : (
        <>
          <div className="wallet-info">
            <div className="wallet-header">
              <button className="reset-button" onClick={resetWallet}>
                🔄 Reset Wallet
              </button>
            </div>

            <div className="info-section">
              <h3>Cuenta Actual</h3>
              <p className="address">{accounts[currentAccountIndex]}</p>
              <p className="balance">Balance: {balance} ETH</p>

              <div className="account-selector">
                <label>Cambiar cuenta: </label>
                <select
                  value={currentAccountIndex}
                  onChange={(e) => changeAccount(parseInt(e.target.value))}
                >
                  {accounts.map((acc, i) => (
                    <option key={i} value={i}>
                      Cuenta {i}: {acc.slice(0, 6)}...{acc.slice(-4)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <ChainManager
              chains={chains}
              activeChainId={chainId}
              onSwitch={changeChain}
              onChainsChanged={setChains}
            />

            <TransferSection
              accounts={accounts}
              currentAccountIndex={currentAccountIndex}
              balanceWei={balanceWei}
              onTransfer={handleTransfer}
            />
          </div>

          <LogsPanel logs={logs} onClear={handleClearLogs} />
        </>
      )}
    </div>
  )
}

export default App
