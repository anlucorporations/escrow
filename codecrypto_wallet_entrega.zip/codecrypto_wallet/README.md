# 🔐 CodeCrypto Wallet — Extensión de Chrome

**Versión 1.0.0** · Wallet Ethereum como extensión de navegador (Manifest V3), al
estilo de MetaMask, con soporte para **EIP-1193**, **EIP-712**, **EIP-1559** y
**EIP-6963**.

Construida con **React 19 + TypeScript + Ethers.js v6** y **Foundry (anvil)** como
blockchain local de desarrollo.

> ⚠️ Proyecto **educativo**. No cifra el mnemonic y no debe usarse con fondos reales.

---

## ✨ Características

### Wallet y cuentas
- Frase de recuperación **BIP-39** (12 palabras) con validación en vivo (diccionario y checksum)
- **Crear una wallet nueva** con copia de seguridad guiada (se confirman 3 palabras al azar)
- **5 cuentas HD** derivadas con BIP-44 (`m/44'/60'/0'/0/i`)
- Auto-carga al abrir: solo pide el mnemonic la primera vez
- Restaura la **cuenta activa** y la **red** al reabrir
- **Transferencias entre cuentas propias** con validación inline del importe
- **Reset** que limpia la wallet conservando el historial de actividad

### Provider y estándares
- `window.codecrypto` (**EIP-1193**) inyectado en todas las páginas y frames
- Descubrimiento multi-wallet **EIP-6963**
- Firma de mensajes **EIP-712** (`eth_signTypedData_v4`)
- Transacciones **EIP-1559** tipo 2 (`maxFeePerGas` / `maxPriorityFeePerGas`)
- **Gestión de redes** (EIP-3085 / EIP-3326): `wallet_addEthereumChain` y
  `wallet_switchEthereumChain`, con alta de redes desde el popup y validación del RPC
- Eventos `accountsChanged` y `chainChanged` emitidos a **todas las pestañas**

### Experiencia de aprobación (como MetaMask)
- `connect.html` (420×650) para elegir qué cuenta compartir con cada dApp
- `notification.html` (400×600) para aprobar o rechazar transacciones y firmas
- **Badge** con el número de solicitudes pendientes y **notificación** de Chrome
- La dApp espera hasta **130 s** (la aprobación caduca a los 120 s)
- Las solicitudes **sobreviven** a que Chrome duerma el service worker
- Cerrar la ventana a mano **rechaza** la solicitud al instante
- **Panel de actividad** en el popup que muestra también lo que ocurre en las dApps:
  llamadas RPC, eventos, transacciones, firmas y errores (historial de 200 entradas
  persistido, con botón para limpiarlo)

### Desarrollo y pruebas
- **dApp de prueba** (`test.html`) con detección multi-wallet e historial de operaciones
- **Foundry**: `anvil` como nodo local, `forge` para contratos y `cast` para el CLI
- **124 comprobaciones automáticas** (67 + 50 de aceptación + 7 en Chrome real) y **ESLint en 0 errores**
- **Errores EIP-1193**: las dApps reciben `error.code` (4001, 4200, 4902, -32602…)
- Visor del `chrome.storage.local` para depurar (`viewextensiondata/`)

---

## 🚀 Inicio rápido

### Requisitos

- **Node.js** 20 o superior
- **[Foundry](https://book.getfoundry.sh/getting-started/installation)** (anvil, forge, cast)

```bash
# Instalación de Foundry (una sola vez)
curl -L https://foundry.paradigm.xyz | bash
foundryup
```

> Los scripts `npm run chain` y `npm run contracts:*` localizan las herramientas
> automáticamente mediante `scripts/foundry.sh`, así que funcionan aunque
> `~/.foundry/bin` no esté en el `PATH`.

### Puesta en marcha

```bash
npm install        # 1. dependencias
npm run chain      # 2. blockchain local (déjalo en su propia terminal)
npm run build      # 3. compila la extensión en dist/
npm run dev        # 4. sirve test.html en http://localhost:5173/test.html
```

### Cargar en Chrome

1. Abre `chrome://extensions/`
2. Activa **"Modo de desarrollador"**
3. Pulsa **"Cargar descomprimida"** y selecciona la carpeta **`dist/`**
4. Abre el popup y carga el mnemonic de prueba (hay un hint verde que lo autocompleta)

**📖 Guía detallada paso a paso: [`INSTRUCCIONES.md`](INSTRUCCIONES.md)**

---

## 🧪 Probar la extensión

1. Con `npm run chain` y `npm run dev` en marcha, abre <http://localhost:5173/test.html>
2. Pulsa **Conectar Wallet** → se abre `connect.html` con las 5 cuentas y sus balances
3. Prueba: enviar transacción, firmar EIP-712, cambiar de red, desconectar

`test.html` trata a `window.codecrypto` exactamente igual que a MetaMask (ambos son
proveedores EIP-1193), así que sirve también para comparar con otras wallets.

### Pruebas automatizadas

```bash
npm test                  # las tres baterías (67 comprobaciones)
npm run test:acceptance   # los 11 casos del enunciado contra anvil real (50)
npm run test:extension    # smoke test en Chrome real (7; requiere puppeteer)
npm run verify            # build + todas las pruebas
npm run test:amount       # conversión ETH → wei (20)
npm run test:contracts    # forge test (6)
npm run test:background   # service worker con chrome simulado (41)
npm run lint              # ESLint (0 errores)
```

`npm run test:acceptance` arranca **anvil** por su cuenta, ejecuta los 11 casos de
`TAREA_PARA_ESTUDIANTE.md` de extremo a extremo (transacciones minadas de verdad,
firma EIP-712 verificada, eventos en las pestañas, reset, badge y selección de
cuenta) y escribe la evidencia en `documentacion/evidencia-fase4.md`.

### Entrega

```bash
bash scripts/package-delivery.sh      # genera codecrypto_wallet_entrega.zip
```

El ZIP incluye el código, `dist/` ya compilado, los contratos y la documentación
vigente; excluye `node_modules` y el historial de desarrollo.

---

## 🔌 API del proveedor

```javascript
// Conectar
const [account] = await window.codecrypto.request({ method: 'eth_requestAccounts' })

// Consultar la cuenta autorizada (devuelve [] si el sitio no está autorizado)
await window.codecrypto.request({ method: 'eth_accounts' })

// Red actual
await window.codecrypto.request({ method: 'eth_chainId' })

// Balance
await window.codecrypto.request({ method: 'eth_getBalance', params: [account, 'latest'] })

// Enviar transacción (se abre la ventana de aprobación)
await window.codecrypto.request({
  method: 'eth_sendTransaction',
  params: [{ from: account, to: '0x…', value: '0x…', data: '0x' }]
})

// Firmar EIP-712
await window.codecrypto.request({
  method: 'eth_signTypedData_v4',
  params: [account, JSON.stringify(typedData)]
})

// Cambiar de red
await window.codecrypto.request({
  method: 'wallet_switchEthereumChain',
  params: [{ chainId: '0xaa36a7' }]
})

// Añadir una red nueva (EIP-3085); la wallet pide permiso para ese RPC
await window.codecrypto.request({
  method: 'wallet_addEthereumChain',
  params: [{
    chainId: '0x13882',
    chainName: 'Polygon Amoy',
    rpcUrls: ['https://rpc-amoy.polygon.technology'],
    nativeCurrency: { name: 'POL', symbol: 'POL', decimals: 18 },
    blockExplorerUrls: ['https://amoy.polygonscan.com']
  }]
})

// Eventos
window.codecrypto.on('accountsChanged', (accounts) => { … })
window.codecrypto.on('chainChanged', (chainId) => { … })
```

---

## 🌐 Redes

| Red | RPC | Chain ID |
|---|---|---|
| Local (Foundry / anvil) | `http://127.0.0.1:8545` | 31337 (`0x7a69`) |
| Sepolia | `https://rpc.sepolia.org` | 11155111 (`0xaa36a7`) |

El mnemonic de prueba (`test test … junk`) es también el de anvil por defecto, así
que las cuentas derivadas coinciden con las del nodo (cuenta 0 =
`0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266`, 10 000 ETH cada una).

---

## 🏗️ Arquitectura

```
dApp (página web)
   │  window.codecrypto.request(…)          ← EIP-1193
   ▼
inject.ts            Crea el provider y anuncia EIP-6963
   │  window.postMessage
   ▼
content-script.ts    Puente aislado → chrome.runtime
   │  chrome.runtime.sendMessage
   ▼
background.ts        Service worker: RPC, aprobaciones, firma (ethers) y eventos
   │
   ├── connect.html / Connect.tsx            Autorizar sitios y elegir cuenta
   ├── notification.html / Notification.tsx  Aprobar o rechazar operaciones
   └── index.html / App.tsx                  Popup: cuentas, red, transferencias, logs
```

**Reparto de responsabilidades:** el popup es solo UI (no importa ethers); toda la
criptografía y la firma ocurren en el service worker, que es el único que lee el
mnemonic desde `chrome.storage.local`.

### Estructura

```
├── src/                    Código fuente (100 % TypeScript)
├── contracts/  test/       Contrato de ejemplo y pruebas (Foundry)
├── scripts/                Iconos, pruebas automatizadas, lanzador de Foundry
├── viewextensiondata/      Visor de chrome.storage.local
├── documentacion/          Plan de mejora e histórico del desarrollo
├── test.html               dApp de pruebas
├── dist/                   Extensión compilada (`npm run build`)
└── foundry.toml            Configuración de Foundry
```

---

## 📋 Cumplimiento del enunciado

Especificaciones funcionales de `TAREA_PARA_ESTUDIANTE.md`:

| Parte | Especificaciones | Estado |
|---|---|---|
| 1 · Core wallet | 1-6 | ✅ todas (incluye generar una wallet nueva) |
| 2 · Operaciones blockchain | 7-10 | ✅ todas |
| 3 · UX y logging | 11-16 | ✅ todas (panel de actividad con las llamadas, eventos, transacciones y firmas de las dApps) |
| 4 · Estándares EIP | 17-20 | ✅ todas (incluye añadir redes con `wallet_addEthereumChain`) |
| 5 · UI avanzada | 20-25 | ✅ todas (validación de formularios con feedback inline) |
| 6 · Persistencia | 26-28 | ✅ todas |
| 7 · Chrome Extension avanzado | 29-36 | ✅ todas |

**37/37 especificaciones implementadas.** Las mejoras pendientes (lint, tipado estricto
y desafíos opcionales) están en `documentacion/PLAN_MEJORA.md`.

---

## 📚 Documentación

| Documento | Contenido |
|---|---|
| [`INSTRUCCIONES.md`](INSTRUCCIONES.md) | Instalación, uso, los 11 casos de prueba y solución de problemas |
| [`GUIA_RAPIDA_TESTING.md`](GUIA_RAPIDA_TESTING.md) | Checklist de verificación rápida (5 minutos) |
| [`CHANGELOG.md`](CHANGELOG.md) | Novedades de la versión 1.0.0 |
| [`TAREA_PARA_ESTUDIANTE.md`](TAREA_PARA_ESTUDIANTE.md) | Enunciado del proyecto |
| [`documentacion/PLAN_MEJORA.md`](documentacion/PLAN_MEJORA.md) | Plan de mejora por fases con su estado |
| [`documentacion/historial/`](documentacion/historial/README.md) | Documentación del proceso de desarrollo |

---

## 🔒 Seguridad y limitaciones

- El **mnemonic se guarda sin cifrar** en `chrome.storage.local` y la wallet no pide
  contraseña: es una simplificación intencionada del alcance educativo.
- Solo el service worker accede a la frase; el popup nunca la maneja para firmar.
- Los permisos se conceden **por origen** y `eth_accounts` solo responde a los
  sitios autorizados.
- No usar con mnemónicos ni fondos reales: la frase de prueba es pública y sus
  claves son conocidas.

---

## 📄 Licencia

MIT
